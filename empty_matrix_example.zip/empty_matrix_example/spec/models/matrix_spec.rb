# encoding: utf-8

require File.join(File.dirname(__FILE__), '..', 'spec_helper')

describe Matrix do
  let(:count_of_rows)    { 3 }
  let(:count_of_columns) { 2 }
  let(:count_of_items)   { count_of_rows * count_of_columns }
  subject { Matrix.new(count_of_rows, count_of_columns, *(1..count_of_items).to_a) }

  it "instance can be initialized" do
    expect { subject }.not_to raise_exception
  end

  it "instance responds to `rows` method" do
    expect(subject).to respond_to(:rows)
  end

  it "#rows returns count of rows" do
    expect(subject.rows).to eq(count_of_rows)
  end

  it "instance responds to `columns` method" do
    expect(subject).to respond_to(:columns)
  end

  it "#columns returns count of columns" do
    expect(subject.columns).to eq(count_of_columns)
  end

  it "instance responds to `[]` method" do
    expect(subject).to respond_to(:'[]')
  end

  it "instance's items can be retreived" do
    #
    # | 1  2  3 |
    # | 4  5  6 |
    #
    matrix = Matrix.new(2, 3, *(1..2*3).to_a)
    expect(matrix[0,0]).to eq(1)
    expect(matrix[0,1]).to eq(2)
    expect(matrix[0,2]).to eq(3)
    expect(matrix[1,0]).to eq(4)
    expect(matrix[1,1]).to eq(5)
    expect(matrix[1,2]).to eq(6)

    #
    # | 1  2 |
    # | 3  4 |
    # | 5  6 |
    #
    matrix = Matrix.new(3, 2, *(1..2*3).to_a)
    expect(matrix[0,0]).to eq(1)
    expect(matrix[0,1]).to eq(2)
    expect(matrix[1,0]).to eq(3)
    expect(matrix[1,1]).to eq(4)
    expect(matrix[2,0]).to eq(5)
    expect(matrix[2,1]).to eq(6)

    #
    # | 1  2  3 |
    # | 4  5  6 |
    # | 7  8  9 |
    #
    matrix = Matrix.new(3, 3, *(1..3*3).to_a)
    expect(matrix[0,0]).to eq(1)
    expect(matrix[0,1]).to eq(2)
    expect(matrix[0,2]).to eq(3)
    expect(matrix[1,0]).to eq(4)
    expect(matrix[1,1]).to eq(5)
    expect(matrix[1,2]).to eq(6)
    expect(matrix[2,0]).to eq(7)
    expect(matrix[2,1]).to eq(8)
    expect(matrix[2,2]).to eq(9)
  end

  it "instance responds to `[]=` method" do
    expect(subject).to respond_to(:'[]=')
  end

  it "instance's items can be modified" do
    matrix = Matrix.new(2, 3, *(1..2*3).to_a)
    expect(matrix[0,2]).to eq(3)
    matrix[0,2] = 9
    expect(matrix[0,2]).to eq(9)
  end

  it "instance responds to `*` method" do
    expect(subject).to respond_to(:'*')
  end

  it "instance can be multiply with a number" do
    #
    # | 1  2  3 |       | 2  4  6 |
    # | 4  5  6 | * 2 = | 8 10 12 |
    #
    matrix = Matrix.new(2, 3, *(1..2*3).to_a) * 2
    expect(matrix).to be_a(Matrix)
    expect(matrix.rows).to eq(2)
    expect(matrix.columns).to eq(3)
    expect(matrix[0,0]).to eq(1 * 2)
    expect(matrix[0,1]).to eq(2 * 2)
    expect(matrix[0,2]).to eq(3 * 2)
    expect(matrix[1,0]).to eq(4 * 2)
    expect(matrix[1,1]).to eq(5 * 2)
    expect(matrix[1,2]).to eq(6 * 2)
  end

  it "instance can be multiply with an other one" do
    a_matrix = Matrix.new(2, 3, *(1..2*3).to_a)
    b_matrix = Matrix.new(3, 2, *(1..2*3).to_a)

    #
    #              |  1  2 |
    #              |  3  4 |
    #              |  5  6 |
    #
    # | 1  2  3 |  | 22 28 |
    # | 4  5  6 |  | 49 64 |
    #
    ab_matrix = a_matrix * b_matrix
    expect(ab_matrix).to be_a(Matrix)
    expect(ab_matrix.rows).to eq(2)
    expect(ab_matrix.columns).to eq(2)
    expect(ab_matrix[0,0]).to eq(22)
    expect(ab_matrix[0,1]).to eq(28)
    expect(ab_matrix[1,0]).to eq(49)
    expect(ab_matrix[1,1]).to eq(64)

    #
    #           |  1  2  3 |
    #           |  4  5  6 |
    #
    # | 1  2 |  |  9 12 15 |
    # | 3  4 |  | 19 26 33 |
    # | 5  6 |  | 29 40 51 |
    #
    ba_matrix = b_matrix * a_matrix
    expect(ba_matrix).to be_a(Matrix)
    expect(ba_matrix.rows).to eq(3)
    expect(ba_matrix.columns).to eq(3)
    expect(ba_matrix[0,0]).to eq(9)
    expect(ba_matrix[0,1]).to eq(12)
    expect(ba_matrix[0,2]).to eq(15)
    expect(ba_matrix[1,0]).to eq(19)
    expect(ba_matrix[1,1]).to eq(26)
    expect(ba_matrix[1,2]).to eq(33)
    expect(ba_matrix[2,0]).to eq(29)
    expect(ba_matrix[2,1]).to eq(40)
    expect(ba_matrix[2,2]).to eq(51)
  end

  it "instance responds to `+` method" do
    expect(subject).to respond_to(:'+')
  end

  it "instance can be added to an other one" do
    a_matrix = Matrix.new(2, 3, *(1..2*3).to_a)
    b_matrix = Matrix.new(2, 3, *(1..2*3).to_a.reverse)

    #
    # | 1  2  3 |   | 6  5  4 |   | 7  7  7 |
    # | 4  5  6 | + | 3  2  1 | = | 7  7  7 |
    #
    ab_matrix = a_matrix + b_matrix
    expect(ab_matrix).to be_a(Matrix)
    expect(ab_matrix.rows).to eq(2)
    expect(ab_matrix.columns).to eq(3)
    expect(ab_matrix[0,0]).to eq(7)
    expect(ab_matrix[0,1]).to eq(7)
    expect(ab_matrix[0,2]).to eq(7)
    expect(ab_matrix[1,0]).to eq(7)
    expect(ab_matrix[1,1]).to eq(7)
    expect(ab_matrix[1,2]).to eq(7)
  end
end
