# encoding: utf-8

class Matrix

  attr_reader :rows, :columns

  def initialize rows, columns, *items
  end

  def [] row, column
  end

  def []= row, column, new_item
  end

  def * other
  end

  def + other
  end
end
